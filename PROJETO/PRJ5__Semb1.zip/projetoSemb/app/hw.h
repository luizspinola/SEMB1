/*
 * hw.h
 *
 *  Created on: Oct 14, 2024
 *      Author: eufil
 */

#ifndef HW_H_
#define HW_H_

#include <stdint.h>

#define CANAL_PWM_BUZZER TIM_CHANNEL_1

uint32_t tempo_em_mili();



#endif /* HW_H_ */
